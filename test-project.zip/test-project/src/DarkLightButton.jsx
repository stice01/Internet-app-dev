import { useState } from 'react'
import orangutan from './assets/orangutan_1600x1000_279157.jpg'
import './App.css'

function DarkLightButton() {
  const [dark, setDark] = useState(true)

  function handleClick() {
    if (dark) {
      setDark(false)
      document.body.classList.add('light')
    } else {
      setDark(true)
      document.body.classList.remove('light')
    }
  }

  let className = 'light-toggle'
  if (!dark) {
    className = 'light-toggle light'
  }

  let buttonText = 'Switch to Light'
  if (!dark) {
    buttonText = 'Switch to Dark'
  }

  return (
    <div className={className}>
      <img src={orangutan} alt="Orangutan" />
      <div className="card">
        <button onClick={handleClick}>
          {buttonText}
        </button>
      </div>
    </div>
  )
}

export default DarkLightButton
